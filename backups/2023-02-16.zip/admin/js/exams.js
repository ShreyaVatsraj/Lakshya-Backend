function createExam() {
    $('#btn-submit').attr('disabled', '');

    $('#btn-submit-text').hide();
    $('#btn-submit-text-saved').hide();
    $('#btn-submit-spinner').show();

    let formData = new FormData();
    formData.append('name', $('#name').val());
    formData.append('description', $('#description').val());
    formData.append('date', $('#date').val());
    formData.append('time', $('#time').val());
    formData.append('duration-in-minutes', $('#duration-in-minutes').val());
    formData.append('faculty-id', $('#faculty-id').val());

    $.ajax({
        method: 'POST',
        url: '../exams/create.php',
        contentType: false,
        processData: false,
        data: formData,
        success: (response) => {
            if (response.status) {
                $('#btn-submit-text').hide();
                $('#btn-submit-text-saved').show();
                $('#btn-submit-spinner').hide();

                setTimeout(() => window.location.href = '../exams', 1000);
            }
        },
        error: (reason) => {
            console.log(reason);
        }
    });
}

function editExam(id) {
    $('#btn-submit').attr('disabled', '');

    $('#btn-submit-text').hide();
    $('#btn-submit-text-saved').hide();
    $('#btn-submit-spinner').show();

    let formData = new FormData();
    formData.append('id', id);
    formData.append('name', $('#name').val());
    formData.append('description', $('#description').val());
    formData.append('date', $('#date').val());
    formData.append('time', $('#time').val());
    formData.append('duration-in-minutes', $('#duration-in-minutes').val());

    $.ajax({
        method: 'POST',
        url: '../exams/edit.php',
        contentType: false,
        processData: false,
        data: formData,
        success: (response) => {
            if (response.status) {
                $('#btn-submit-text').hide();
                $('#btn-submit-text-saved').show();
                $('#btn-submit-spinner').hide();

                setTimeout(() => window.location.href = '../exams', 1000);
            }
        }
    });

    return false;
}

function showDeleteExamConfirmation(id) {
    $('#btn-yes').attr('data-id', id);
    $('#modal-delete').modal('show');
}

function deleteExam() {
    let id = $('#btn-yes').attr('data-id');
    if (id == null)
        return;

    window.location.href = '../exams/delete.php?id=' + id;
}