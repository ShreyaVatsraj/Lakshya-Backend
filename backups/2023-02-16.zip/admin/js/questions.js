let count = 0;

function createQuestionDiv() {

    count++;
    let html = `
        <div class="card card-outline card-info single-question">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="title">Question ${count}</label>
                            <input type="text" class="form-control title" id="title" placeholder="Enter question" required />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="option1">Option 1</label>
                            <input class="form-control option1" id="option1" placeholder="Option 1" required></input>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label for="option2">Option 2</label>
                            <input type="text" class="form-control option2" id="option2" placeholder="Option 2" required />
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label for="option3">Option 3</label>
                            <input type="text" class="form-control option3" id="option3" placeholder="Option 3" required />
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label for="option4">Option 4</label>
                            <input type="text" class="form-control option4" id="option4" placeholder="Option 4" required />
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label for="correctOptionNumber">Correct Option Number</label>
                            <select id="correctOptionNumber" class="custom-select correctOptionNumber">
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    $('#questions').append(html);
}

function createQuestions() {
    $('#btn-submit').attr('disabled', '');

    $('#btn-submit-text').hide();
    $('#btn-submit-text-saved').hide();
    $('#btn-submit-spinner').show();

    let formData = new FormData();
    formData.append('examId', $('#exam').val());

    let questions = $('.single-question');
    for (let i = 0; i < questions.length; i++) {
        formData.append('title[]', $(questions[i]).find('.title').val());
        formData.append('option1[]', $(questions[i]).find('.option1').val());
        formData.append('option2[]', $(questions[i]).find('.option2').val());
        formData.append('option3[]', $(questions[i]).find('.option3').val());
        formData.append('option4[]', $(questions[i]).find('.option4').val());
        formData.append('correctOptionNumber[]', $(questions[i]).find('.correctOptionNumber').val());
    }

    $.ajax({
        method: 'POST',
        url: '../questions/create.php',
        contentType: false,
        processData: false,
        data: formData,
        success: (response) => {
            if (response.status) {
                $('#btn-submit-text').hide();
                $('#btn-submit-text-saved').show();
                $('#btn-submit-spinner').hide();

                setTimeout(() => window.location.href = '../questions', 1000);
            }
        },
        error: (reason) => {
            console.log(reason);
        }
    });

    return false;
}

function showDeleteQuestionsConfirmation(id) {
    $('#btn-yes').attr('data-id', id);
    $('#modal-delete').modal('show');
}

function deleteQuestions() {
    let id = $('#btn-yes').attr('data-id');
    if (id == null)
        return;

    window.location.href = '../questions/delete.php?id=' + id;
}