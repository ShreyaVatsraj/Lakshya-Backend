function addFaculty() {
    $('#btn-submit').attr('disabled', '');

    $('#btn-submit-text').hide();
    $('#btn-submit-text-saved').hide();
    $('#btn-submit-spinner').show();

    let formData = new FormData();
    formData.append('name', $('#name').val());
    formData.append('pnumber', $('#pnumber').val());
    formData.append('user-id', $('#user-id').val());

    $.ajax({
        method: 'POST',
        url: '../faculties/add.php',
        contentType: false,
        processData: false,
        data: formData,
        success: (response) => {
            if (response.status) {
                $('#btn-submit-text').hide();
                $('#btn-submit-text-saved').show();
                $('#btn-submit-spinner').hide();

                setTimeout(() => window.location.href = '../faculties', 1000);
            }
        },
        error: (reason) => {
            console.log(reason);
        }
    });

    return false;
}

function editFaculty(id) {
    $('#btn-submit').attr('disabled', '');

    $('#btn-submit-text').hide();
    $('#btn-submit-text-saved').hide();
    $('#btn-submit-spinner').show();

    let formData = new FormData();
    formData.append('id', id);
    formData.append('name', $('#name').val());
    formData.append('pnumber', $('#pnumber').val());

    $.ajax({
        method: 'POST',
        url: '../faculties/edit.php',
        contentType: false,
        processData: false,
        data: formData,
        success: (response) => {
            if (response.status) {
                $('#btn-submit-text').hide();
                $('#btn-submit-text-saved').show();
                $('#btn-submit-spinner').hide();

                setTimeout(() => window.location.href = '../faculties', 1000);
            }
        }
    });

    return false;
}

function showDeleteFacultyConfirmation(id) {
    $('#btn-yes').attr('data-id', id);
    $('#modal-delete').modal('show');
}

function deleteFaculty() {
    let id = $('#btn-yes').attr('data-id');
    if (id == null)
        return;

    window.location.href = '../faculties/delete.php?id=' + id;
}