<?php

require("../includes/init.php");
require(pathOf('admin/includes/auth.php'));

execute("DELETE FROM `Faculties` WHERE `Id` = ?", [$_GET['id']]);
header('Location: ' . urlOf('admin/faculties'));
